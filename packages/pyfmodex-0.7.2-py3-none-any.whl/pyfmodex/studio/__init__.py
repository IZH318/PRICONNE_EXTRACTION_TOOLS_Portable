"""The main system for FMOD Studio."""

from .system import StudioSystem
