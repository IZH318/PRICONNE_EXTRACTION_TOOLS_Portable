"""
Run the `archspec` CLI as a module.
"""

import sys

from .cli import main

sys.exit(main())
