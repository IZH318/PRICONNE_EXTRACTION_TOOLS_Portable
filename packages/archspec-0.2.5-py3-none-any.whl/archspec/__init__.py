"""Init file to avoid namespace packages"""

__version__ = "0.2.5"
